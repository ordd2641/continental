import { useEffect, useState } from "react";
import { subscribeInventory, changeQty } from "../services/inventoryService";

export default function OrdersPage() {
  const [inventory,setInventory]=useState([]);
  const [cart,setCart]=useState({});
  const [custom,setCustom]=useState({});
  const [orders,setOrders]=useState(()=>JSON.parse(localStorage.getItem("continentalOrders")||"[]"));
  const [nextOrder,setNextOrder]=useState(()=>Number(localStorage.getItem("continentalOrderCounter")||"1"));

  useEffect(()=>subscribeInventory(setInventory),[]);

  useEffect(()=>{
    localStorage.setItem("continentalOrders",JSON.stringify(orders));
  },[orders]);

  useEffect(()=>{
    localStorage.setItem("continentalOrderCounter",String(nextOrder));
  },[nextOrder]);

  const addItem=(name,qty)=>{
    qty=Number(qty||0);
    if(qty<=0) return;
    setCart(p=>({...p,[name]:(p[name]||0)+qty}));
  };

  const createOrder=()=>{
    const items=Object.entries(cart);
    if(!items.length) return;

    setOrders(p=>[...p,{
      id:nextOrder,
      items,
      createdAt:Date.now()
    }]);

    setNextOrder(v=>v+1);
    setCart({});
  };

  const markDelivered=async(order)=>{
    for(const [name,qty] of order.items){
      const item=inventory.find(i=>i.name===name);
      if(item){
        await changeQty(item.id,qty,"Заказ поставки");
      }
    }

    setOrders(p=>p.filter(x=>x.id!==order.id));
  };

  const copyOrder=(order)=>{
    const text=order.items.map(([n,q])=>`${n} x${q}`).join("\n");
    navigator.clipboard.writeText(text);
  };

  return (
    <div style={{display:"grid",gridTemplateColumns:"1fr 1fr 1fr",gap:"16px"}}>
      <div>
        <h3>Склад</h3>
        {inventory.map(i=>(
          <div key={i.id}>
            {i.name} ({i.quantity})
            <div>
              <button onClick={()=>addItem(i.name,10)}>10</button>
              <button onClick={()=>addItem(i.name,50)}>50</button>
              <button onClick={()=>addItem(i.name,100)}>100</button>
              <input style={{width:"60px"}}
                value={custom[i.name]||""}
                onChange={e=>setCustom(p=>({...p,[i.name]:e.target.value}))}
              />
              <button onClick={()=>addItem(i.name,custom[i.name])}>Добавить</button>
            </div>
          </div>
        ))}
      </div>

      <div>
        <h3>Формирование заказа <button onClick={()=>setCart({})}>Очистить все</button></h3>

        {Object.entries(cart).map(([name,qty])=>(
          <div key={name}>
            <input
              value={qty}
              onChange={e=>setCart(p=>({...p,[name]:Number(e.target.value)||0}))}
              style={{width:"70px"}}
            />
            {" "}{name}
            <button onClick={()=>{
              const c={...cart};
              delete c[name];
              setCart(c);
            }}>✕</button>
          </div>
        ))}

        <div style={{position:"sticky",bottom:0,marginTop:"10px"}}>
          <button onClick={createOrder}>Заказать</button>
        </div>
      </div>

      <div>
        <h3>Ожидают доставки</h3>

        {orders.map(order=>(
          <div key={order.id} style={{border:"1px solid #666",padding:"8px",marginBottom:"8px"}}>
            <b>Заказ #{order.id}</b>

            {order.items.map(([n,q])=>
              <div key={n}>{n} x{q}</div>
            )}

            <button onClick={()=>copyOrder(order)}>Скопировать</button>
            <button onClick={()=>markDelivered(order)}>Доставлено</button>
            <button
              onClick={()=>{
                const ok = window.confirm(
                 `Удалить заказ #${order.id}?`
               );

              if(ok){
               setOrders(p=>p.filter(x=>x.id!==order.id));
    }
  }}
>
  ✕
</button>
          </div>
        ))}
      </div>
    </div>
  );
}
